# Created by Varun at 11/04/19

import glob
import re
from nltk.corpus import stopwords
stops = set(stopwords.words('english'))
files = glob.glob("rtweet_twitter_proj2_immigration.csv")
print(files)

with open('rtweet_twitter_proj2_mueller.csv') as infile, open('combined_final_mueller.txt', 'w') as outfile:
    for line in infile:
        if not line.strip(): continue  # skip the empty line
        text = re.sub(r'([^\s\w]|_)+', '', line)
        text = ' '.join([word for word in text.split() if word not in stops])
        outfile.write(text.lower())
        outfile.write('\n')
